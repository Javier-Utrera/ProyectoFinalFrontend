export const environment = {
    production: true,
    baseUrl: 'https://bookroom.duckdns.org/api',
    wsBaseUrl: 'wss://bookroom.duckdns.org/ws'
  };
  console.log('Usando environment.prod.ts');